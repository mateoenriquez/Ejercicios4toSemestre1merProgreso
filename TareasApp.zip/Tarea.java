public class Tarea implements Comparable<Tarea> {
    private int id;
    private String nombre;
    private String categoria;
    private float presupuesto;
    private int prioridad;

    public Tarea() {
        this.id = 0;
        this.nombre = "Sin nombre";
        this.categoria = "Administrativa";
        this.presupuesto = 0;
        this.prioridad = 1;
    }

    public Tarea(int id, String nombre, String categoria, float presupuesto, int prioridad) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.presupuesto = presupuesto;
        this.prioridad = prioridad;
    }

    public float recalcularPresupuesto() {
        switch (categoria) {
            case "Administrativa": return presupuesto * 0.9f;
            case "Directiva": return presupuesto * 0.8f;
            case "Operativa": return presupuesto * 0.95f;
            default: return presupuesto;
        }
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCategoria() { return categoria; }
    public float getPresupuesto() { return presupuesto; }
    public int getPrioridad() { return prioridad; }

    @Override
    public int compareTo(Tarea otra) {
        return Integer.compare(otra.prioridad, this.prioridad);
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Categoría: " + categoria +
               ", Presupuesto: $" + presupuesto + ", Prioridad: " + prioridad +
               ", Presupuesto Ajustado: $" + recalcularPresupuesto();
    }
}