import javax.swing.*;
import java.awt.*;

public class AppTareas extends JFrame {
    private JTextField txtId, txtNombre, txtPresupuesto, txtPrioridad;
    private JComboBox<String> cbCategoria;
    private JTextArea txtArea;
    private JLabel lblTotales;
    private ColaTareas cola = new ColaTareas();

    public AppTareas() {
        setTitle("Gestión de Tareas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelEntrada = new JPanel(new GridLayout(6, 2));
        panelEntrada.add(new JLabel("ID:"));
        txtId = new JTextField(); panelEntrada.add(txtId);

        panelEntrada.add(new JLabel("Nombre:"));
        txtNombre = new JTextField(); panelEntrada.add(txtNombre);

        panelEntrada.add(new JLabel("Categoría:"));
        cbCategoria = new JComboBox<>(new String[]{"Administrativa", "Directiva", "Operativa"});
        panelEntrada.add(cbCategoria);

        panelEntrada.add(new JLabel("Presupuesto:"));
        txtPresupuesto = new JTextField(); panelEntrada.add(txtPresupuesto);

        panelEntrada.add(new JLabel("Prioridad (1-12):"));
        txtPrioridad = new JTextField(); panelEntrada.add(txtPrioridad);

        JButton btnAgregar = new JButton("Agregar Tarea");
        panelEntrada.add(btnAgregar);

        JButton btnTotales = new JButton("Mostrar Totales");
        panelEntrada.add(btnTotales);

        add(panelEntrada, BorderLayout.NORTH);

        txtArea = new JTextArea(10, 50);
        txtArea.setEditable(false);
        add(new JScrollPane(txtArea), BorderLayout.CENTER);

        lblTotales = new JLabel("Totales por categoría:");
        add(lblTotales, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> agregarTarea());
        btnTotales.addActionListener(e -> mostrarTotales());

        pack();
        setVisible(true);
    }

    private void agregarTarea() {
        try {
            int id = Integer.parseInt(txtId.getText());
            String nombre = txtNombre.getText();
            String categoria = cbCategoria.getSelectedItem().toString();
            float presupuesto = Float.parseFloat(txtPresupuesto.getText());
            int prioridad = Integer.parseInt(txtPrioridad.getText());

            if (prioridad < 1 || prioridad > 12) {
                JOptionPane.showMessageDialog(this, "Prioridad debe estar entre 1 y 12.");
                return;
            }

            Tarea tarea = new Tarea(id, nombre, categoria, presupuesto, prioridad);
            if (!cola.agregarTarea(tarea)) {
                JOptionPane.showMessageDialog(this, "ID duplicado. Tarea no añadida.");
                return;
            }

            txtArea.setText(cola.mostrarTareas());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Verifica los datos numéricos.");
        }
    }

    private void mostrarTotales() {
        String categoria = cbCategoria.getSelectedItem().toString();
        float[] totales = cola.calcularTotalesPorCategoria(categoria);
        lblTotales.setText(String.format("Total original: $%.2f | Ajustado: $%.2f", totales[0], totales[1]));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AppTareas::new);
    }
}