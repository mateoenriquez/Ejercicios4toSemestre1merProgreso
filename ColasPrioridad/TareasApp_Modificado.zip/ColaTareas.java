import java.util.PriorityQueue;

public class ColaTareas {
    private PriorityQueue<Tarea> cola = new PriorityQueue<>();

    public boolean agregarTarea(Tarea t) {
        for (Tarea tarea : cola) {
            if (tarea.getId() == t.getId()) return false;
        }
        return cola.offer(t);
    }

    public String mostrarTareas() {
        StringBuilder sb = new StringBuilder();
        for (Tarea t : cola) sb.append(t).append("\n");
        return sb.toString();
    }

    public float[] calcularTotalesPorCategoria(String categoria) {
        float totalOriginal = 0, totalAjustado = 0;
        for (Tarea t : cola) {
            if (t.getCategoria().equals(categoria)) {
                totalOriginal += t.getPresupuesto();
                totalAjustado += t.recalcularPresupuesto();
            }
        }
        return new float[]{totalOriginal, totalAjustado};
    }
}