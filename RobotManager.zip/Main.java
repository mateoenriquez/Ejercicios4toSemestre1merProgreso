import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ventanafinal ventana = new ventanafinal();
            ventana.setTitle("Gestión de Robots");
            ventana.setSize(700, 600);
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setVisible(true);
        });
    }
}