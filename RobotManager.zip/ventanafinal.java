import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class ventanafinal extends JFrame {
    private JPanel panel1;
    private JSpinner spID;
    private JTextField txtNombreRobot;
    private JComboBox<String> cboNivelEnergia;
    private JTextField txtPuntaje;
    private JComboBox<String> cboCategoria;
    private JTextArea txtListaRobots;
    private JButton btnAgregar;
    private JButton btnOrdenar;
    private JComboBox<String> cboBuscarCategoria;
    private JButton btnBuscar;
    private JTextArea txtCategoriaEncontrada;
    private JTextField txtID;
    private JTextField txtNombreEditar;
    private JComboBox<String> cboEnergiaEditar;
    private JTextField txtPuntajeEditar;
    private JComboBox<String> cboCategoriaEditar;
    private JButton btnEditar;
    private JTextArea txtMostrarRobotEditado;

    private ArrayList<Robot> listaRobots = new ArrayList<>();

    public ventanafinal() {
        setContentPane(panel1);
        cargarDatosIniciales();

        btnAgregar.addActionListener(e -> agregarRobot());
        btnOrdenar.addActionListener(e -> ordenarPorPuntaje());
        btnBuscar.addActionListener(e -> buscarPorCategoria());
        btnEditar.addActionListener(e -> editarRobotPorID());
    }

    private void cargarDatosIniciales() {
        listaRobots.add(new Robot(1, "ALPHA", 80, 100, "DRON"));
        listaRobots.add(new Robot(20, "OMEGA", 40, 55, "SUBMARINO"));
        listaRobots.add(new Robot(150, "TITAN", 90, 80, "TERRESTRE"));
        listaRobots.add(new Robot(95, "NEBULA", 60, 60, "AÉREO"));
        mostrarRobots();
    }

    private void mostrarRobots() {
        txtListaRobots.setText("");
        for (Robot r : listaRobots) {
            txtListaRobots.append(r.toString() + "\n");
        }
    }

    private void agregarRobot() {
        try {
            int id = (Integer) spID.getValue();
            String nombre = txtNombreRobot.getText().trim();
            int energia = Integer.parseInt(cboNivelEnergia.getSelectedItem().toString());
            int puntaje = Integer.parseInt(txtPuntaje.getText().trim());
            String categoria = cboCategoria.getSelectedItem().toString();

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.");
                return;
            }
            if (puntaje <= 0 || puntaje % 5 != 0) {
                JOptionPane.showMessageDialog(this, "El puntaje debe ser positivo y múltiplo de 5.");
                return;
            }

            Robot existente = null;
            for (Robot r : listaRobots) {
                if (r.getId() == id) {
                    existente = r;
                    break;
                }
            }

            if (existente != null) {
                existente.setNombre(nombre);
                existente.setEnergia(energia);
                existente.setPuntaje(puntaje);
                existente.setCategoria(categoria);
            } else {
                listaRobots.add(new Robot(id, nombre, energia, puntaje, categoria));
            }

            mostrarRobots();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error en los datos ingresados.");
        }
    }

    private void ordenarPorPuntaje() {
        listaRobots.sort((r1, r2) -> Integer.compare(r2.getPuntaje(), r1.getPuntaje()));
        mostrarRobots();
    }

    private void buscarPorCategoria() {
        String categoriaSeleccionada = cboBuscarCategoria.getSelectedItem().toString();
        StringBuilder resultado = new StringBuilder();
        boolean encontrado = false;

        for (Robot r : listaRobots) {
            if (r.getCategoria().equalsIgnoreCase(categoriaSeleccionada)) {
                int nuevaEnergia = Math.min(r.getEnergia() + 20, 100);
                r.setEnergia(nuevaEnergia);
                resultado.append(r.toString()).append("\n");
                encontrado = true;
            }
        }

        if (encontrado) {
            txtCategoriaEncontrada.setText(resultado.toString());
        } else {
            txtCategoriaEncontrada.setText("No se encontraron robots en la categoría seleccionada.");
        }
    }

    private void editarRobotPorID() {
        try {
            int id = Integer.parseInt(txtID.getText().trim());
            String nombre = txtNombreEditar.getText().trim();
            int energia = Integer.parseInt(cboEnergiaEditar.getSelectedItem().toString());
            int puntaje = Integer.parseInt(txtPuntajeEditar.getText().trim());
            String categoria = cboCategoriaEditar.getSelectedItem().toString();

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.");
                return;
            }
            if (puntaje <= 0 || puntaje % 5 != 0) {
                JOptionPane.showMessageDialog(this, "El puntaje debe ser positivo y múltiplo de 5.");
                return;
            }

            boolean encontrado = false;
            for (Robot r : listaRobots) {
                if (r.getId() == id) {
                    r.setNombre(nombre);
                    r.setEnergia(energia);
                    r.setPuntaje(puntaje);
                    r.setCategoria(categoria);
                    txtMostrarRobotEditado.setText("Robot actualizado:\n" + r.toString());
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "No se encontró el robot con ese ID.");
            }

            mostrarRobots();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese todos los campos correctamente.");
        }
    }
}